package com.magnet.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView result,solution;
    MaterialButton C, Bracketo,bracketb;
    MaterialButton multiply,addition,subtract,divide;
    MaterialButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b0;
    MaterialButton equalto,ac,dot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        result = findViewById(R.id.result);
        solution = findViewById(R.id.solution);

        assign(C,R.id.c);
        assign(Bracketo,R.id.openb);
        assign(bracketb,R.id.closeb);
        assign(multiply,R.id.multiply);
        assign(addition,R.id.plus);
        assign(subtract,R.id.minus);
        assign(divide,R.id.divide);
        assign(equalto,R.id.equal);
        assign(ac,R.id.ac);
        assign(dot,R.id.dot);
        assign(b1,R.id.but1);
        assign(b2,R.id.but2);
        assign(b3,R.id.but3);
        assign(b4,R.id.but4);
        assign(b5,R.id.but5);
        assign(b6,R.id.but6);
        assign(b7,R.id.but7);
        assign(b8,R.id.but8);
        assign(b9,R.id.but9);
        assign(b0,R.id.but0);
//        assign(c,R.id.c);



    }

    void assign(MaterialButton btn,int id){
        btn = findViewById(id);
        btn.setOnClickListener(this);
    }
    @Override
    public void onClick(View view) {

        MaterialButton button =(MaterialButton) view;
        String buttontext = button.getText().toString();
        String datatocalculate = solution.getText().toString();




        if(buttontext.equals("AC")) {
            solution.setText("");
            result.setText("0");
            return;
        }


        if(buttontext.equals("=")) {
            solution.setText(result.getText());
            return;
        }

        if(buttontext.equals("C")) {

            datatocalculate = datatocalculate.substring(0,datatocalculate.length()-1);

        }else {

            datatocalculate = datatocalculate+buttontext;

        }

        solution.setText(datatocalculate);

        String finalResult = getResult(datatocalculate);

        if (!finalResult.equals("err")){
            result.setText(finalResult);
        }
    }

    String getResult(String data){
        try{
            Context context  = Context.enter();
            context.setOptimizationLevel(-1);
            Scriptable scriptable = context.initStandardObjects();
            String finalResult =  context.evaluateString(scriptable,data,"Javascript",1,null).toString();
            if(finalResult.endsWith(".0")){
                finalResult = finalResult.replace(".0","");
            }
            return finalResult;
        }catch (Exception e){
            return "";
        }
    }

}

